/*
  ShopEase – Web Programming Assignment 2
  Made with JavaScript, using variables, arrays, objects, functions,
  if/else, loops, DOM selectors and events as covered in class.
*/

// Each product is an object. All products are stored in an array.
const products = [
  {id:1, name:'Wireless Studio Headphones', category:'Electronics', brand:'SoundMax', price:5499, oldPrice:6999, rating:4.8, image:'headphones.jpg', tag:'Best Seller', featured:true, newItem:false, best:true, offer:true, description:'Comfortable over-ear wireless headphones with rich sound, a soft headband and long-lasting battery.'},
  {id:2, name:'Classic Smart Watch', category:'Electronics', brand:'TechZone', price:7499, oldPrice:8999, rating:4.7, image:'watch.jpg', tag:'Popular', featured:true, newItem:true, best:true, offer:true, description:'Modern smartwatch with a clear display, activity tracking and a stylish everyday design.'},
  {id:3, name:'Nova Smartphone', category:'Electronics', brand:'TechZone', price:28999, oldPrice:32500, rating:4.6, image:'phone.jpg', tag:'New', featured:false, newItem:true, best:false, offer:true, description:'A smartphone with a large vibrant screen, reliable performance and a slim finish.'},
  {id:4, name:'Slim Everyday Laptop', category:'Electronics', brand:'TechZone', price:49999, oldPrice:52999, rating:4.5, image:'laptop.jpg', tag:'Featured', featured:true, newItem:false, best:false, offer:false, description:'Lightweight laptop for study, projects and daily tasks with a comfortable portable design.'},
  {id:5, name:'Compact Digital Camera', category:'Electronics', brand:'TechZone', price:15999, oldPrice:17999, rating:4.4, image:'camera.jpg', tag:'', featured:false, newItem:false, best:false, offer:false, description:'Capture your favorite everyday moments with this simple compact digital camera.'},
  {id:6, name:'Wireless Everyday Earbuds', category:'Electronics', brand:'SoundMax', price:3199, oldPrice:3999, rating:4.7, image:'earbuds.jpg', tag:'Hot Deal', featured:false, newItem:true, best:true, offer:true, description:'Pocket-sized wireless earbuds with a rechargeable case for music and calls on the go.'},
  {id:7, name:'Blue Denim Jacket', category:'Clothing', brand:'UrbanWear', price:4299, oldPrice:4999, rating:4.5, image:'jacket.jpg', tag:'New', featured:true, newItem:true, best:false, offer:true, description:'A casual denim-style jacket that is easy to pair with your favorite everyday outfits.'},
  {id:8, name:'Cozy Everyday Hoodie', category:'Clothing', brand:'UrbanWear', price:2999, oldPrice:3799, rating:4.6, image:'hoodie.jpg', tag:'Best Seller', featured:false, newItem:false, best:true, offer:true, description:'Soft comfortable hoodie suitable for daily wear in cooler weather.'},
  {id:9, name:'Classic White Sneakers', category:'Shoes', brand:'StepUp', price:4999, oldPrice:5999, rating:4.9, image:'sneaker.jpg', tag:'Best Seller', featured:true, newItem:false, best:true, offer:true, description:'Clean, versatile sneakers with a comfortable everyday fit and classic look.'},
  {id:10, name:'Performance Running Shoes', category:'Shoes', brand:'StepUp', price:5999, oldPrice:6999, rating:4.5, image:'runner.jpg', tag:'New', featured:false, newItem:true, best:false, offer:true, description:'Lightweight sporty shoes designed for an active routine and casual walks.'},
  {id:11, name:'Everyday Carry Tote Bag', category:'Accessories', brand:'StyleHub', price:2499, oldPrice:2999, rating:4.7, image:'bag.jpg', tag:'Popular', featured:true, newItem:false, best:true, offer:true, description:'A stylish tote bag with enough room for your daily essentials.'},
  {id:12, name:'Modern Sun Glasses', category:'Accessories', brand:'StyleHub', price:1599, oldPrice:1999, rating:4.3, image:'sunglasses.jpg', tag:'', featured:false, newItem:true, best:false, offer:false, description:'A comfortable and fashionable pair of sunglasses for sunny days.'},
  {id:13, name:'Travel Backpack', category:'Accessories', brand:'StyleHub', price:3799, oldPrice:4499, rating:4.6, image:'backpack.jpg', tag:'New', featured:false, newItem:true, best:true, offer:true, description:'A convenient backpack with handy storage for university, short trips and everyday use.'},
  {id:14, name:'Kitchen Blender', category:'Home Appliances', brand:'HomeNest', price:6499, oldPrice:7999, rating:4.8, image:'blender.jpg', tag:'Best Seller', featured:true, newItem:false, best:true, offer:true, description:'A practical kitchen blender for preparing shakes, smoothies and everyday recipes.'},
  {id:15, name:'Warm Table Lamp', category:'Home Appliances', brand:'HomeNest', price:3599, oldPrice:4299, rating:4.5, image:'lamp.jpg', tag:'New', featured:false, newItem:true, best:false, offer:true, description:'A simple decorative lamp that brings a warm feeling to your bedroom or study desk.'},
  {id:16, name:'Electric Tea Kettle', category:'Home Appliances', brand:'HomeNest', price:3999, oldPrice:4999, rating:4.7, image:'kettle.jpg', tag:'Featured', featured:true, newItem:false, best:true, offer:true, description:'An easy-to-use electric kettle for preparing hot water, tea and coffee.'}
];

const categories = [
  {name:'Electronics', image:'category-electronics.jpg'},
  {name:'Clothing', image:'category-clothing.jpg'},
  {name:'Shoes', image:'category-shoes.jpg'},
  {name:'Accessories', image:'category-accessories.jpg'},
  {name:'Home Appliances', image:'category-home-appliances.jpg'}
];

const slides = [
  {title:'Fresh fashion, better value', eyebrow:'NEW SEASON · CLOTHING & STYLE', subtitle:'Find your everyday fashion favorites at ShopEase.', image:'promo-fashion.jpg', category:'Clothing'},
  {title:'Your everyday tech, for less', eyebrow:'SHOPEASE ELECTRONICS · SPECIAL DEALS', subtitle:'Explore great-value headphones, smartwatches and more.', image:'promo-electronics.jpg', category:'Electronics'},
  {title:'Make every corner feel like home', eyebrow:'HOME ESSENTIALS · SHOP NOW', subtitle:'Practical kitchen and home picks for every day.', image:'promo-home.jpg', category:'Home Appliances'}
];

const app = document.getElementById('app');
const navDrawer = document.getElementById('navigationDrawer');
const drawerOverlay = document.getElementById('drawerOverlay');
const searchBox = document.getElementById('globalSearch');

// localStorage remembers the cart and wishlist after the browser refreshes.
function readSaved(key, fallback) {
  try { const value = localStorage.getItem(key); return value ? JSON.parse(value) : fallback; }
  catch (error) { return fallback; }
}
let cart = readSaved('shopease_cart', {});
let wishlist = readSaved('shopease_wishlist', []);
let orders = readSaved('shopease_orders', []);
let user = readSaved('shopease_user', null);
let settings = readSaved('shopease_settings', {dark:false, emails:true});
let filters = {category:'All', brand:'All', maxPrice:50000, minRating:0, sort:'featured', search:''};
let currentSlide = 0;
let detailQuantity = 1;
let authMode = 'login';
let toastTimeout;

function saveData() {
  localStorage.setItem('shopease_cart', JSON.stringify(cart));
  localStorage.setItem('shopease_wishlist', JSON.stringify(wishlist));
  localStorage.setItem('shopease_orders', JSON.stringify(orders));
  localStorage.setItem('shopease_user', JSON.stringify(user));
  localStorage.setItem('shopease_settings', JSON.stringify(settings));
}
function money(value) { return 'Rs. ' + Number(value).toLocaleString('en-PK'); }
function findProduct(id) { return products.find(function(p) { return p.id === Number(id); }); }
// Real Unsplash photographs are loaded online. Bundled JPGs are used when offline.
// The images and product names are illustrative, not manufacturer listings.
const stockPhotos = {
  'headphones.jpg':'photo-1505740420928-5e560c06d30e',
  'watch.jpg':'photo-1523275335684-37898b6baf30',
  'phone.jpg':'photo-1511707171634-5f897ff02aa9',
  'laptop.jpg':'photo-1496181133206-80ce9b88a853',
  'camera.jpg':'photo-1516035069371-29a1b244cc32',
  'earbuds.jpg':'photo-1606220588913-b3aacb4d2f46',
  'jacket.jpg':'photo-1544923246-77307dd654cb',
  'hoodie.jpg':'photo-1556821840-3a63f95609a7',
  'sneaker.jpg':'photo-1549298916-b41d501d3772',
  'runner.jpg':'photo-1542291026-7eec264c27ff',
  'bag.jpg':'photo-1548036328-c9fa89d128fa',
  'sunglasses.jpg':'photo-1511499767150-a48a237f0083',
  'backpack.jpg':'photo-1553062407-98eeb64c6a62',
  'lamp.jpg':'photo-1507473885765-e6ed057f782c',
  'category-electronics.jpg':'photo-1505740420928-5e560c06d30e',
  'category-clothing.jpg':'photo-1529139574466-a303027c1d8b',
  'category-shoes.jpg':'photo-1549298916-b41d501d3772',
  'category-accessories.jpg':'photo-1548036328-c9fa89d128fa',
  'category-home-appliances.jpg':'photo-1556911220-bff31c812dba',
  'promo-electronics.jpg':'photo-1519389950473-47ba0277781c',
  'promo-fashion.jpg':'photo-1483985988355-763728e1935b',
  'promo-home.jpg':'photo-1556911220-bff31c812dba'
};
function imagePath(file) {
  if (stockPhotos[file]) {
    const banner = file.startsWith('promo-');
    const category = file.startsWith('category-');
    const width = banner ? 1600 : (category ? 900 : 900);
    return 'https://images.unsplash.com/' + stockPhotos[file] + '?auto=format&fit=crop&w=' + width + '&q=85';
  }
  return 'images/' + file;
}
// Simple error listener makes local photo backups work when offline or if a link fails.
document.addEventListener('error', function(event) {
  const img = event.target;
  if (img.tagName === 'IMG' && img.dataset.localImage && !img.dataset.usedFallback) {
    img.dataset.usedFallback = '1';
    img.src = 'images/' + img.dataset.localImage;
  }
}, true);

function safe(value) { return String(value).replace(/[&<>"']/g, function(c) { return {'&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'}[c]; }); }
function sectionTitle(title, subtitle, url) { return `<div class="section-heading"><div><h2>${title}</h2>${subtitle ? `<p>${subtitle}</p>` : ''}</div>${url ? `<a class="link-arrow" href="${url}">View all →</a>` : ''}</div>`; }
function pageHeading(heading, subtitle) { return `<div class="container page-title"><div class="eyebrow">ShopEase / Shopping made easy</div><h1>${heading}</h1>${subtitle ? `<p>${subtitle}</p>` : ''}</div>`; }

// Display one card for every product. map() and join() create HTML dynamically.
function productCard(product) {
  const saved = wishlist.includes(product.id);
  return `<article class="product-card">
    <div class="product-image"><a href="#/product/${product.id}" aria-label="View ${safe(product.name)}"><img src="${imagePath(product.image)}" data-local-image="${product.image}" alt="${safe(product.name)}"></a>
      ${product.tag ? `<span class="product-badge">${safe(product.tag)}</span>` : ''}
      <button type="button" class="heart-button ${saved ? 'active' : ''}" data-action="wishlist" data-id="${product.id}" aria-label="${saved ? 'Remove from' : 'Add to'} wishlist" title="Wishlist">${saved ? '♥' : '♡'}</button>
    </div>
    <div class="product-info"><div class="product-brand">${safe(product.brand)} · ${safe(product.category)}</div>
      <h3>${safe(product.name)}</h3><div class="rating" aria-label="Rated ${product.rating} out of 5">★ ${product.rating.toFixed(1)} <span>/ 5</span></div>
      <div class="price-line"><span class="price">${money(product.price)}</span>${product.oldPrice ? `<span class="old-price">${money(product.oldPrice)}</span>` : ''}</div>
      <div class="product-actions"><button class="btn small" data-action="add" data-id="${product.id}" type="button">+ Add to Cart</button><a class="btn secondary small" href="#/product/${product.id}">View Details</a></div>
    </div></article>`;
}
function cards(items, className) { return `<div class="product-grid ${className || ''}">${items.length ? items.map(productCard).join('') : emptyState('No products found', 'Try choosing different filters or searching another name.', '#/products')}</div>`; }
function emptyState(title, message, link, label) { return `<div class="empty-state"><div class="emoji">🛍️</div><h2>${title}</h2><p>${message}</p>${link ? `<a class="btn" href="${link}">${label || 'Browse Products'}</a>` : ''}</div>`; }
function categoryCards() {
  return `<div class="category-grid">${categories.map(function(cat) { return `<a href="#/category/${encodeURIComponent(cat.name)}" class="category-card"><div class="category-art"><img src="${imagePath(cat.image)}" data-local-image="${cat.image}" alt="${safe(cat.name)}"></div><strong>${safe(cat.name)}</strong></a>`; }).join('')}</div>`;
}
function renderHome() {
  app.innerHTML = `<div class="container">
    <section class="hero" aria-label="Promotional slideshow">
      ${slides.map(function(slide, i) { return `<article class="hero-slide ${i === currentSlide ? 'active' : ''}" data-slide="${i}"><img src="${imagePath(slide.image)}" data-local-image="${slide.image}" alt="Featured ${slide.category} promotional photograph"><div class="hero-content"><span class="eyebrow">${slide.eyebrow}</span><h1>${slide.title}</h1><p>${slide.subtitle}</p><a href="#/category/${encodeURIComponent(slide.category)}" class="btn">Shop Now →</a></div></article>`; }).join('')}
      <div class="hero-dots" aria-label="Choose slide">${slides.map(function(s, i) { return `<button type="button" data-action="slide" data-slide-to="${i}" class="${i === currentSlide ? 'active' : ''}" aria-label="Show promotion ${i+1}"></button>`; }).join('')}</div>
      <div class="hero-controls"><button class="round-btn" type="button" data-action="previous" aria-label="Previous slide">‹</button><button class="round-btn" type="button" data-action="next" aria-label="Next slide">›</button></div>
    </section>
    <div class="mini-benefits"><div class="benefit"><span class="sym">🚚</span><div><strong>Explore Categories</strong><small>Explore all your favorite products</small></div></div><div class="benefit"><span class="sym">✦</span><div><strong>Everyday Deals</strong><small>offers in PKR</small></div></div><div class="benefit"><span class="sym">♡</span><div><strong>Your Wishlist</strong><small>Add items to your wishlist</small></div></div></div>
  </div>
  <section class="section container" id="home-categories">${sectionTitle('Top Categories','Find what you need.','#/categories')}${categoryCards()}</section>
  <section class="section container">${sectionTitle('Featured products','Handpicked favorites to explore.','#/products')}${cards(products.filter(function(p) { return p.featured; }).slice(0,8))}</section>
  <section class="container promo-strip"><div><span class="eyebrow" style="color:#ffcb75">SHOP MORE · SAVE MORE</span><h2>Deals worth discovering.</h2><p>Discover great-value picks across all categories.</p></div><a href="#/offers" class="btn">See Today's Offers →</a></section>
  <section class="section container">${sectionTitle('New arrivals','Fresh finds for your daily routine.','#/products')}${cards(products.filter(function(p) { return p.newItem; }).slice(0,4))}</section>
  <section class="section container">${sectionTitle('Best sellers','Shop what everyone is loving.','#/products')}${cards(products.filter(function(p) { return p.best; }).slice(0,4))}</section>
  <section class="section container">${sectionTitle('Special offers','Save on popular ShopEase picks.','#/offers')}${cards(products.filter(function(p) { return p.offer; }).slice(0,4))}</section>`;
}
function filterProducts() {
  let result = products.filter(function(product) {
    return (filters.category === 'All' || product.category === filters.category) &&
      (filters.brand === 'All' || product.brand === filters.brand) &&
      product.price <= Number(filters.maxPrice) &&
      product.rating >= Number(filters.minRating) &&
      product.name.toLowerCase().includes(filters.search.toLowerCase());
  });
  if (filters.sort === 'price-low') result.sort(function(a,b) { return a.price-b.price; });
  else if (filters.sort === 'price-high') result.sort(function(a,b) { return b.price-a.price; });
  else if (filters.sort === 'rating') result.sort(function(a,b) { return b.rating-a.rating; });
  else if (filters.sort === 'name') result.sort(function(a,b) { return a.name.localeCompare(b.name); });
  return result;
}
function option(value, label, current) { return `<option value="${safe(value)}" ${current === value ? 'selected' : ''}>${safe(label)}</option>`; }
function renderProducts(title, onlyOffers) {
  const visible = filterProducts().filter(function(p) { return !onlyOffers || p.offer; });
  const brandNames = [...new Set(products.map(function(p) { return p.brand; }))].sort();
  app.innerHTML = `${pageHeading(title || 'All Products', 'Search, compare and find your perfect everyday pick.')}
    <div class="container catalog-layout">
      <aside class="sidebar" aria-label="Product filters"><h3>Filter Products</h3>
        <div class="filter-block"><h4>Product Category</h4><select class="field" id="categoryFilter" aria-label="Filter by category">${option('All', 'All Categories', filters.category)}${categories.map(function(c) { return option(c.name,c.name,filters.category); }).join('')}</select></div>
        <div class="filter-block"><h4>Price Filter</h4><p class="small-note">Maximum price: <b id="priceDisplay">${money(filters.maxPrice)}</b></p><input class="range" id="priceFilter" type="range" min="1000" max="50000" step="500" value="${filters.maxPrice}" aria-label="Maximum price"></div>
        <div class="filter-block"><h4>Brand Filter</h4><select class="field" id="brandFilter" aria-label="Filter by brand">${option('All','All Brands',filters.brand)}${brandNames.map(function(b) { return option(b,b,filters.brand); }).join('')}</select></div>
        <div class="filter-block"><h4>Rating Filter</h4><select class="field" id="ratingFilter" aria-label="Minimum rating">${option('0','All Ratings',String(filters.minRating))}${option('4','4 Stars & Up',String(filters.minRating))}${option('4.5','4.5 Stars & Up',String(filters.minRating))}${option('4.7','4.7 Stars & Up',String(filters.minRating))}</select></div>
        <button class="btn secondary full" data-action="reset-filters" type="button">Clear All Filters</button>
      </aside>
      <section class="catalog-content"><div class="catalog-topbar"><span><b id="visibleCount">${visible.length}</b> products found</span><label>Sort by <select class="field" id="sortFilter">${option('featured','Featured',filters.sort)}${option('price-low','Price: Low to High',filters.sort)}${option('price-high','Price: High to Low',filters.sort)}${option('rating','Highest Rated',filters.sort)}${option('name','Name A to Z',filters.sort)}</select></label></div><div id="catalogResults">${cards(visible,'catalog-products')}</div></section>
    </div>`;
}
function updateCatalogResults() {
  const target = document.getElementById('catalogResults');
  if (!target) return;
  const onlyOffers = location.hash.startsWith('#/offers');
  const visible = filterProducts().filter(function(p) { return !onlyOffers || p.offer; });
  target.innerHTML = cards(visible,'catalog-products');
  document.getElementById('visibleCount').textContent = visible.length;
}
function renderCategories() { app.innerHTML = `${pageHeading('Shop by Category', 'Browse the five product categories from your assignment.')}<section class="container section">${categoryCards()}<div style="margin-top:35px">${sectionTitle('Explore all products','Use the product filters to narrow your search.','#/products')}${cards(products.slice(0,4))}</div></section>`; }
function renderDetails(id) {
  const p = findProduct(id);
  if (!p) { app.innerHTML = pageHeading('Product not found', '') + `<div class="container">${emptyState('Sorry!', 'This product is unavailable.', '#/products')}</div>`; return; }
  detailQuantity = 1;
  app.innerHTML = `<div class="container breadcrumb"><a href="#/home">Home</a> / <a href="#/products">Products</a> / <a href="#/category/${encodeURIComponent(p.category)}">${safe(p.category)}</a> / ${safe(p.name)}</div>
    <div class="container detail-layout"><div class="detail-image"><img src="${imagePath(p.image)}" data-local-image="${p.image}" alt="Large picture of ${safe(p.name)}"></div>
    <div class="detail-copy"><span class="eyebrow">${safe(p.category)} · ${safe(p.brand)}</span><h1>${safe(p.name)}</h1><div class="rating">★ ${p.rating.toFixed(1)} <span>/ 5 customer rating</span></div>
      <div class="price-line"><span class="price">${money(p.price)}</span><span class="old-price">${money(p.oldPrice)}</span></div><p>${safe(p.description)}</p>
      <div class="detail-feature">✓ Selected for ShopEase's everyday collection</div><div class="detail-feature">✓ Easy shopping-cart quantity controls</div><div class="detail-feature">✓ All prices are sample data</div>
      <p><strong>Choose quantity</strong></p><div class="qty-control"><button data-action="detail-minus" aria-label="Decrease quantity">−</button><span id="detailQty">1</span><button data-action="detail-plus" aria-label="Increase quantity">+</button></div>
      <div class="detail-cta"><button class="btn" data-action="detail-add" data-id="${p.id}">+ Add to Cart</button><button class="btn secondary" data-action="wishlist" data-id="${p.id}">♡ ${wishlist.includes(p.id) ? 'Remove Wishlist' : 'Add to Wishlist'}</button></div>
      <a class="link-arrow" href="#/products">← Continue shopping</a></div></div>
    <section class="container section">${sectionTitle('You may also like','More products from the same category.','#/products')}${cards(products.filter(function(x) { return x.category === p.category && x.id !== p.id; }).slice(0,4))}</section>`;
}
function renderCart() {
  const ids = Object.keys(cart).filter(function(id) { return cart[id] > 0 && findProduct(id); });
  const total = ids.reduce(function(sum,id) { return sum + findProduct(id).price * cart[id]; },0);
  const count = ids.reduce(function(sum,id) { return sum + cart[id]; },0);
  const list = ids.length ? ids.map(function(id) { const p=findProduct(id); return `<div class="cart-item"><a href="#/product/${p.id}"><img src="${imagePath(p.image)}" data-local-image="${p.image}" alt="${safe(p.name)}"></a><div><div class="product-brand">${safe(p.brand)}</div><h3><a href="#/product/${p.id}">${safe(p.name)}</a></h3><p>${money(p.price)} each</p><div class="qty-control"><button type="button" data-action="cart-minus" data-id="${p.id}" aria-label="Decrease ${safe(p.name)} quantity">−</button><span>${cart[id]}</span><button type="button" data-action="cart-plus" data-id="${p.id}" aria-label="Increase ${safe(p.name)} quantity">+</button></div><br><button class="text-button" data-action="remove" data-id="${p.id}">Remove product</button></div><strong>${money(p.price * cart[id])}</strong></div>`; }).join('') : emptyState('Your cart is empty', 'Add some products and they will appear here.', '#/products');
  app.innerHTML = `${pageHeading('Your Shopping Cart', 'Review your products and update quantities before checking out.')}<div class="container cart-layout"><div class="cart-list">${list}</div><div class="summary-card"><h2>Order Summary</h2><div class="summary-row"><span>Items (${count})</span><strong>${money(total)}</strong></div><div class="summary-row"><span>Demo delivery</span><strong>Free</strong></div><div class="summary-row total"><span>Total Bill</span><span id="billTotal">${money(total)}</span></div><button class="btn full" data-action="checkout" ${ids.length ? '' : 'disabled'}>Place Demo Order →</button><p class="small-note" style="margin:12px 0 0">For coursework only. No real payments, shipping or purchases.</p></div></div>`;
}
function renderWishlist() {
  const items = products.filter(function(p) { return wishlist.includes(p.id); });
  app.innerHTML = `${pageHeading('My Wishlist','Save products you love and come back later.')}<section class="container section">${cards(items)}</section>`;
}
function renderAuth() {
  app.innerHTML = `${pageHeading('Login / Signup')}
    <section class="container"><div class="panel form-card"><div class="tab-row"><button type="button" data-action="auth-tab" data-tab="login" class="${authMode === 'login' ? 'active' : ''}">Login</button><button type="button" data-action="auth-tab" data-tab="signup" class="${authMode === 'signup' ? 'active' : ''}">Create Account</button></div>
    <form id="authForm" class="form-grid" novalidate>
      ${authMode === 'signup' ? `<label>Full Name<input class="field" name="fullName" id="fullName" type="text" placeholder="Enter your full name" autocomplete="name"><span class="form-error" id="nameError"></span></label>` : ''}
      <label>Email Address<input class="field" name="email" id="email" type="email" placeholder="example@email.com" autocomplete="email"><span class="form-error" id="emailError"></span></label>
      <label>Password<input class="field" name="password" id="password" type="password" placeholder="At least 6 characters" autocomplete="${authMode === 'signup' ? 'new-password' : 'current-password'}"><span class="form-error" id="passwordError"></span></label>
      ${authMode === 'signup' ? `<label>Confirm Password<input class="field" name="confirmPassword" id="confirmPassword" type="password" placeholder="Repeat your password" autocomplete="new-password"><span class="form-error" id="confirmError"></span></label>` : ''}
      <button class="btn full" type="submit">${authMode === 'signup' ? 'Create Demo Account' : 'Validate & Login'}</button><p id="authResult" class="form-success" role="status"></div></section>`;
}
function renderAbout() { app.innerHTML = `${pageHeading('About ShopEase','A simple shopping experience, built as a student assignment.')}<section class="container section two-col"><div class="panel"><span class="eyebrow">OUR STORY</span><h2>Shopping made easy</h2><p>ShopEase is a sample online store designed for Web Programming Assignment 2. It brings together electronics, clothing, shoes, accessories, and home appliances in one interactive website.</p><a href="#/products" class="btn">Explore Products</a></div><div class="panel"><h2>What we built</h2><div class="info-card"><h3>HTML structure</h3><p>Navigation, images, forms, buttons and semantic sections.</p></div><div class="info-card"><h3>CSS design</h3><p>Flexbox, Grid, responsive layouts, transitions and animations.</p></div><div class="info-card"><h3>JavaScript interaction</h3><p>Slideshow, search, filters, wishlist, cart and input validation.</p></div></div></section>`; }
function renderContact() { app.innerHTML = `${pageHeading('Contact Us','Send a sample message to the ShopEase team.')}<section class="container section two-col"><div class="panel"><h2>We would love to hear from you</h2><p>For this student demo, the contact form checks input only and does not send email.</p><p><strong>Demo email:</strong> support@shopease.example</p><p><strong>Location:</strong> Islamabad, Pakistan</p><p><strong>Hours:</strong> Monday – Saturday, 9 AM – 6 PM</p></div><form class="panel form-grid" id="contactForm" novalidate><label>Your Name<input class="field" name="contactName" required placeholder="Your name"></label><label>Email Address<input class="field" name="contactEmail" type="email" required placeholder="you@example.com"></label><label>Your Message<textarea class="field" name="contactMessage" required placeholder="Write your message..."></textarea></label><span class="form-error" id="contactError"></span><button class="btn" type="submit">Validate Message</button></form></section>`; }
function renderProfile() { app.innerHTML = `${pageHeading('My Profile','Your ShopEase demo account information.')}<section class="container section"><div class="panel" style="max-width:640px">${user ? `<span class="eyebrow">WELCOME BACK</span><h2>${safe(user.name)}</h2><p><strong>Email:</strong> ${safe(user.email)}</p><p class="small-note">This is saved in your own browser as a frontend demonstration.</p><button class="btn secondary" data-action="logout">Logout</button>` : `${emptyState('You are not logged in','Use the sample login or signup form to continue.','#/login','Go to Login / Signup')}`}</div></section>`; }
function renderOrders() {
  const content = orders.length ? orders.map(function(o) { return `<div class="order-card"><h3>Demo Order #${safe(o.id)}</h3><p class="muted">Placed ${safe(o.date)} · ${o.items.reduce(function(n,item) {return n + item.quantity;},0)} items</p><p>${o.items.map(function(item) { return safe(item.name) + ' × ' + item.quantity; }).join(' · ')}</p><strong>Order total: ${money(o.total)}</strong></div>`; }).join('') : emptyState('No demo orders yet','Place a order from your cart to see it here.','#/products');
  app.innerHTML = `${pageHeading('My Orders','Your local, sample checkout history.')}<section class="container section"><div class="panel">${content}<p class="small-note">Orders here are saved only in your browser; this is not a real purchase or delivery service.</p></div></section>`;
}
function renderSettings() { app.innerHTML = `${pageHeading('Settings','Change the preferences for your demo shop.')}<section class="container section"><div class="panel" style="max-width:720px"><h2>Preferences</h2><label class="checkbox-setting"><input type="checkbox" id="darkSetting" ${settings.dark ? 'checked' : ''}><span>Use dark mode</span></label><label class="checkbox-setting"><input type="checkbox" id="emailSetting" ${settings.emails ? 'checked' : ''}><span>Show demo email update preference</span></label><button class="btn" data-action="save-settings">Save Preferences</button><p class="small-note">Settings are saved in your browser with localStorage.</p></div></section>`; }
function showSlide(index) {
  currentSlide = (index + slides.length) % slides.length;
  document.querySelectorAll('.hero-slide').forEach(function(slide, i) { slide.classList.toggle('active', i === currentSlide); });
  document.querySelectorAll('.hero-dots button').forEach(function(dot, i) { dot.classList.toggle('active', i === currentSlide); });
}
function addToCart(id, quantity) {
  const p = findProduct(id);
  if (!p) return;
  cart[id] = (cart[id] || 0) + (quantity || 1);
  saveData(); updateHeader(); toast(p.name + ' added to cart');
}
function updateHeader() {
  const count = Object.keys(cart).reduce(function(sum,id) { return sum + (cart[id] || 0); },0);
  document.getElementById('cartCount').textContent = count;
  document.getElementById('wishlistCount').textContent = wishlist.length;
  document.getElementById('accountLabel').textContent = user ? user.name.split(' ')[0] : 'Account';
  document.getElementById('drawerGreeting').textContent = user ? 'Hello, ' + user.name + ' 👋' : 'Welcome to ShopEase 👋';
}
function toggleWishlist(id) {
  const p = findProduct(id);
  if (!p) return;
  if (wishlist.includes(id)) { wishlist = wishlist.filter(function(x) { return x !== id; }); toast('Removed from wishlist'); }
  else { wishlist.push(id); toast('Added to wishlist'); }
  saveData(); updateHeader(); render();
}
function toast(message) {
  const note = document.getElementById('toast');
  note.textContent = message;
  note.classList.add('show');
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(function() { note.classList.remove('show'); }, 2800);
}
function openDrawer() {
  navDrawer.classList.add('open'); drawerOverlay.classList.add('open');
  navDrawer.setAttribute('aria-hidden','false'); drawerOverlay.setAttribute('aria-hidden','false');
  document.getElementById('menuButton').setAttribute('aria-expanded','true');
  document.body.style.overflow = 'hidden';
}
function closeDrawer() {
  navDrawer.classList.remove('open'); drawerOverlay.classList.remove('open');
  navDrawer.setAttribute('aria-hidden','true'); drawerOverlay.setAttribute('aria-hidden','true');
  document.getElementById('menuButton').setAttribute('aria-expanded','false');
  document.body.style.overflow = '';
}
function resetFilters() { filters = {category:'All', brand:'All', maxPrice:50000, minRating:0, sort:'featured', search:''}; searchBox.value = ''; }
function render() {
  const parts = decodeURIComponent(location.hash.replace(/^#\/?/,'')).split('/');
  const page = parts[0] || 'home';
  const names = {home:'Home',products:'Products',offers:'Special Offers',categories:'Categories',product:'Product Details',category:'Category',cart:'Cart',wishlist:'Wishlist',login:'Login / Signup',about:'About Us',contact:'Contact Us',profile:'My Profile',orders:'My Orders',settings:'Settings'};
  document.title = 'ShopEase | ' + (names[page] || 'Shop Online');
  document.querySelectorAll('[data-nav]').forEach(function(item) { item.classList.toggle('active', item.dataset.nav === page); });
  document.body.classList.toggle('dark',settings.dark);
  updateHeader();
  if (page === 'home') renderHome();
  else if (page === 'products') { filters.category = 'All'; renderProducts('All Products',false); }
  else if (page === 'offers') renderProducts('Special Offers',true);
  else if (page === 'categories') renderCategories();
  else if (page === 'category') { filters.category = parts[1] || 'All'; filters.search = ''; searchBox.value = ''; renderProducts(filters.category,false); }
  else if (page === 'product') renderDetails(parts[1]);
  else if (page === 'cart') renderCart();
  else if (page === 'wishlist') renderWishlist();
  else if (page === 'login') renderAuth();
  else if (page === 'about') renderAbout();
  else if (page === 'contact') renderContact();
  else if (page === 'profile') renderProfile();
  else if (page === 'orders') renderOrders();
  else if (page === 'settings') renderSettings();
  else { location.hash = '#/home'; }
}

// One click listener handles buttons created dynamically by JavaScript.
document.addEventListener('click', function(event) {
  const button = event.target.closest('[data-action]');
  if (!button) return;
  const action = button.dataset.action;
  const id = Number(button.dataset.id);
  if (action === 'add') addToCart(id,1);
  else if (action === 'wishlist') toggleWishlist(id);
  else if (action === 'next') showSlide(currentSlide + 1);
  else if (action === 'previous') showSlide(currentSlide - 1);
  else if (action === 'slide') showSlide(Number(button.dataset.slideTo));
  else if (action === 'reset-filters') { resetFilters(); render(); }
  else if (action === 'detail-minus') { detailQuantity = Math.max(1,detailQuantity - 1); document.getElementById('detailQty').textContent = detailQuantity; }
  else if (action === 'detail-plus') { detailQuantity++; document.getElementById('detailQty').textContent = detailQuantity; }
  else if (action === 'detail-add') addToCart(id,detailQuantity);
  else if (action === 'cart-plus' || action === 'cart-minus') {
    if (action === 'cart-plus') cart[id]++;
    else cart[id] = Math.max(1,cart[id] - 1);
    saveData(); render();
  }
  else if (action === 'remove') { delete cart[id]; saveData(); render(); toast('Product removed from cart'); }
  else if (action === 'auth-tab') { authMode = button.dataset.tab; renderAuth(); }
  else if (action === 'logout') { user = null; saveData(); updateHeader(); location.hash = '#/login'; toast('Logged out of the demo account'); }
  else if (action === 'save-settings') {
    settings.dark = document.getElementById('darkSetting').checked;
    settings.emails = document.getElementById('emailSetting').checked;
    saveData(); render(); toast('Preferences saved');
  }
  else if (action === 'checkout') {
    const ids = Object.keys(cart).filter(function(key) { return cart[key] > 0 && findProduct(key); });
    if (!ids.length) return;
    const items = ids.map(function(key) { return {name:findProduct(key).name, quantity:cart[key]}; });
    const total = ids.reduce(function(sum,key) { return sum + findProduct(key).price * cart[key]; },0);
    const order = {id:String(Date.now()).slice(-7), date:new Date().toLocaleDateString('en-PK'), items:items, total:total};
    orders.unshift(order); cart = {}; saveData(); updateHeader(); location.hash='#/orders'; render(); toast('Order placed successfully');
  }
});

// Update filters immediately without refreshing the browser page.
document.addEventListener('input', function(event) {
  if (event.target.id === 'priceFilter') {
    filters.maxPrice = Number(event.target.value);
    document.getElementById('priceDisplay').textContent = money(filters.maxPrice);
    updateCatalogResults();
  }
});
document.addEventListener('change', function(event) {
  const id = event.target.id;
  if (id === 'categoryFilter') filters.category = event.target.value;
  else if (id === 'brandFilter') filters.brand = event.target.value;
  else if (id === 'ratingFilter') filters.minRating = Number(event.target.value);
  else if (id === 'sortFilter') filters.sort = event.target.value;
  else return;
  updateCatalogResults();
});

document.addEventListener('submit', function(event) {
  if (event.target.id === 'authForm') {
    event.preventDefault();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;
    const emailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    const passwordValid = password.length >= 6;
    document.getElementById('emailError').textContent = emailValid ? '' : 'Enter a valid email address.';
    document.getElementById('passwordError').textContent = passwordValid ? '' : 'Password must contain at least 6 characters.';
    let name = email.split('@')[0];
    let extraValid = true;
    if (authMode === 'signup') {
      name = document.getElementById('fullName').value.trim();
      const confirm = document.getElementById('confirmPassword').value;
      document.getElementById('nameError').textContent = name.length >= 2 ? '' : 'Enter your full name (at least 2 characters).';
      document.getElementById('confirmError').textContent = confirm === password && !!confirm ? '' : 'Passwords do not match.';
      extraValid = name.length >= 2 && !!confirm && confirm === password;
    }
    if (emailValid && passwordValid && extraValid) {
      user = {name:name, email:email}; // Never store actual passwords in localStorage.
      saveData(); updateHeader();
      document.getElementById('authResult').textContent = 'Form validated! Opening your demo profile...';
      location.hash = '#/profile'; toast('Form validated successfully');
    }
  }
  else if (event.target.id === 'contactForm') {
    event.preventDefault();
    const f = event.target;
    const name = f.elements.contactName.value.trim();
    const email = f.elements.contactEmail.value.trim();
    const message = f.elements.contactMessage.value.trim();
    const valid = name.length >= 2 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) && message.length >= 10;
    document.getElementById('contactError').textContent = valid ? 'Details validated. This demo does not send real emails.' : 'Enter a name, valid email and a message of at least 10 characters.';
    if (valid) toast('Your message passed validation');
  }
});

document.getElementById('searchForm').addEventListener('submit', function(event) {
  event.preventDefault();
  filters.search = searchBox.value.trim();
  filters.category = 'All';
  if (!location.hash.startsWith('#/products')) location.hash = '#/products';
  else render();
});
document.getElementById('menuButton').addEventListener('click',openDrawer);
document.getElementById('closeDrawer').addEventListener('click',closeDrawer);
drawerOverlay.addEventListener('click',closeDrawer);
navDrawer.addEventListener('click',function(event) { if (event.target.closest('a')) closeDrawer(); });
document.getElementById('logoutButton').addEventListener('click', function() {
  user = null; saveData(); closeDrawer(); updateHeader(); location.hash='#/login'; render(); toast('You have logged out of the demo account');
});
document.addEventListener('keydown',function(event) { if (event.key === 'Escape') closeDrawer(); });
window.addEventListener('hashchange',function() { closeDrawer(); render(); window.scrollTo(0,0); });

// Change promotional slide every 5 seconds while viewing Home.
setInterval(function() { if (!location.hash || location.hash.startsWith('#/home')) showSlide(currentSlide + 1); },5000);
if (!location.hash) location.hash = '#/home';
render();
